-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 24 Février 2014 à 14:13
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `test20/02`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `proce_mention_etape`(code_formation_init char(4), code_etape_init varchar(10), 
out mention_out varchar(100), out etape_out varchar(100))
begin
select f.MENTION, v.ETAPE
into mention_out, etape_out
from formation f, voeu v
where f.CODE_FORMATION = v.CODE_FORMATION
and v.CODE_FORMATION = code_formation_init and v.CODE_ETAPE = code_etape_init;
SELECT mention_out, etape_out;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `choix`
--

CREATE TABLE IF NOT EXISTS `choix` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `INFORMATION` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `TEXTE` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `I_FK_CHOIX_INFORMATION` (`INFORMATION`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Structure de la table `cursus`
--

CREATE TABLE IF NOT EXISTS `cursus` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_ETUDIANT` bigint(20) NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `ANNEE_DEBUT` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `ANNEE_FIN` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `CURSUS` text COLLATE utf8_unicode_ci NOT NULL,
  `ETABLISSEMENT` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `NOTE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`,`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `CODE_FORMATION` (`CODE_FORMATION`),
  KEY `I_FK_CURSUS_DOSSIER` (`ID_ETUDIANT`,`CODE_FORMATION`,`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `dependre`
--

CREATE TABLE IF NOT EXISTS `dependre` (
  `ID_DOSSIER` int(11) NOT NULL,
  `CODE_ETAPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID_DOSSIER`,`CODE_ETAPE`),
  KEY `CODE_ETAPE` (`CODE_ETAPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `document_general`
--

CREATE TABLE IF NOT EXISTS `document_general` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `document_general`
--

INSERT INTO `document_general` (`ID`, `NOM`) VALUES
(1, 'Curriculum-vitae détaillé.'),
(2, 'Lettre de motivation manuscrite.'),
(3, 'Relevé de notes du Baccalauréat ou équivalent (copie) et de toutes les années de formation suivies après le baccalauréat, si nécessaire traduits en français par un traducteur assermenté.'),
(4, 'Attestations des diplômes obtenus (Baccalauréat, DEUG, DUT, BTS... ) si nécessaire traduits en français par un traducteur assermenté.'),
(5, 'Eventuellement, pour les étudiants en D.U.T, avis pédagogique du professeur responsable.'),
(6, 'Pour les étudiants de classes préparatoires : avis pour équivalence du conseil de classe, photocopies de leur admissibilité aux écoles de commerce, le cas échéant.'),
(7, 'Pour les candidats ressortissants de l’union européenne (sauf bac français) : programme détaillé des enseignements suivis en dernière année d’études secondaires visé par le chef d’établissement (document traduit en français).'),
(8, 'Copie de la carte nationale d’identité ou du passeport.');

-- --------------------------------------------------------

--
-- Structure de la table `document_specifique`
--

CREATE TABLE IF NOT EXISTS `document_specifique` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DOSSIER_PDF` int(11) NOT NULL,
  `NOM` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `I_FK_DOCUMENT_SPECIFIQUE_FORMATION` (`DOSSIER_PDF`),
  KEY `DOSSIER_PDF` (`DOSSIER_PDF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `dossier`
--

CREATE TABLE IF NOT EXISTS `dossier` (
  `ID_ETUDIANT` bigint(20) NOT NULL,
  `INE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GENRE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `AUTRE` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NOM` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PRENOM` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ADRESSE` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEMENT` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE_POSTAL` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `VILLE` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_NAISSANCE` date NOT NULL,
  `LIEU_NAISSANCE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `FIXE` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PORTABLE` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `LANGUES` text COLLATE utf8_unicode_ci NOT NULL,
  `NATIONALITE` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `SERIE_BAC` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ANNEE_BAC` year(4) DEFAULT NULL,
  `ETABLISSEMENT_BAC` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEPARTEMENT_BAC` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAYS_BAC` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVITE` text COLLATE utf8_unicode_ci NOT NULL,
  `TITULAIRE` int(11) NOT NULL,
  `VILLE_PREFEREE` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTRES_ELEMENTS` text COLLATE utf8_unicode_ci,
  `INFORMATIONS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `I_FK_DOSSIER_FORMATION1` (`CODE_FORMATION`),
  KEY `I_FK_DOSSIER_ETUDIANT` (`ID_ETUDIANT`),
  KEY `ID_TITULAIRE_idx` (`TITULAIRE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `dossier_pdf`
--

CREATE TABLE IF NOT EXISTS `dossier_pdf` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CODE_FORMATION` (`CODE_FORMATION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_ETUDIANT` bigint(20) NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `MOIS_DEBUT` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `ANNEE_DEBUT` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `MOIS_FIN` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ANNEE_FIN` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTREPRISE` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `FONCTION` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`,`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `I_FK_EXPERIENCE_DOSSIER` (`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `CODE_FORMATION` (`CODE_FORMATION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `faculte`
--

CREATE TABLE IF NOT EXISTS `faculte` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `faculte`
--

INSERT INTO `faculte` (`ID`, `NOM`) VALUES
(1, 'Faculté déconomie gestion'),
(2, 'Faculté de sciences');

-- --------------------------------------------------------

--
-- Structure de la table `faire`
--

CREATE TABLE IF NOT EXISTS `faire` (
  `CODE_ETAPE` char(7) COLLATE utf8_unicode_ci NOT NULL,
  `ID_ETUDIANT` bigint(20) NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `ORDRE` smallint(6) NOT NULL,
  PRIMARY KEY (`CODE_ETAPE`,`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `I_FK_FAIRE_VOEU` (`CODE_ETAPE`),
  KEY `I_FK_FAIRE_DOSSIER` (`ID_ETUDIANT`,`CODE_FORMATION`),
  KEY `CODE_FORMATION` (`CODE_FORMATION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

CREATE TABLE IF NOT EXISTS `formation` (
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `MENTION` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `INFORMATIONS` text COLLATE utf8_unicode_ci,
  `MODALITES` text COLLATE utf8_unicode_ci,
  `FACULTE` int(11) NOT NULL,
  PRIMARY KEY (`CODE_FORMATION`),
  KEY `ID_FACULTE_idx` (`FACULTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `formation`
--

INSERT INTO `formation` (`CODE_FORMATION`, `MENTION`, `INFORMATIONS`, `MODALITES`, `FACULTE`) VALUES
('0000', 'Autres formations', NULL, '', 1),
('3BGE', 'Licence MIAGE Gestion', NULL, '', 1),
('3SIN', 'Licence MIAGE Informatique', NULL, '', 1),
('5BIG', 'Master MIAGE', NULL, '<p>bonjour</p>', 1),
('SIN3', 'Licence informatique', NULL, '', 2);

-- --------------------------------------------------------

--
-- Structure de la table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `ID` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `DOSSIER_PDF` int(11) NOT NULL,
  `LIBELLE` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `EXPLICATIONS` text COLLATE utf8_unicode_ci,
  `ORDRE` smallint(6) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `I_FK_INFORMATION_FORMATION` (`DOSSIER_PDF`),
  KEY `ID_TYPE_idx` (`TYPE`),
  KEY `DOSSIER_PDF` (`DOSSIER_PDF`),
  KEY `DOSSIER_PDF_2` (`DOSSIER_PDF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `se_derouler`
--

CREATE TABLE IF NOT EXISTS `se_derouler` (
  `ID` int(11) NOT NULL,
  `CODE_ETAPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `RESPONSABLE` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL_RESPONSABLE` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`,`CODE_ETAPE`),
  KEY `I_FK_SE_DEROULER_VILLE` (`ID`),
  KEY `I_FK_SE_DEROULER_VOEU` (`CODE_ETAPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `titulaire`
--

CREATE TABLE IF NOT EXISTS `titulaire` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LIBELLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `titulaire`
--

INSERT INTO `titulaire` (`ID`, `LIBELLE`) VALUES
(1, 'Titulaire d''un diplôme français'),
(2, 'Titulaire d''un diplôme de l''union européenne'),
(3, 'Titulaire d''un diplôme hors de l''union européenne');

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `LIBELLE` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `type`
--

INSERT INTO `type` (`ID`, `LIBELLE`) VALUES
('CheckBox', 'Case à cocher'),
('CheckBoxGroup', 'Groupe de cases à cocher'),
('RadioButtonGroup', 'Groupe de boutons radio'),
('TextArea', 'Zone de texte multilignes'),
('TextBox', 'Zone de texte');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `LOGIN` varchar(20) NOT NULL,
  `PASSWORD` char(32) NOT NULL,
  `DROITS` tinyint(3) NOT NULL COMMENT '1 = Administrateur, 2 = Responsable, 3 = Secrétaire',
  PRIMARY KEY (`LOGIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`LOGIN`, `PASSWORD`, `DROITS`) VALUES
('Administrateur', '21232f297a57a5a743894a0e4a801fc3', 3),
('Responsable', 'bd86bced84fb3aef951fb07de8c533c7', 2),
('Secrétaire', '5ebe2294ecd0e0f08eab7690d2a6ee69', 1);

-- --------------------------------------------------------

--
-- Structure de la table `ville`
--

CREATE TABLE IF NOT EXISTS `ville` (
  `ID` int(11) NOT NULL,
  `NOM` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `ville`
--

INSERT INTO `ville` (`ID`, `NOM`) VALUES
(1, 'Marseille'),
(2, 'Aix en Provence'),
(3, 'Gap'),
(4, 'Paris'),
(5, 'Arles');

-- --------------------------------------------------------

--
-- Structure de la table `voeu`
--

CREATE TABLE IF NOT EXISTS `voeu` (
  `CODE_ETAPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_FORMATION` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `ETAPE` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `DOSSIER_PDF` int(11) DEFAULT NULL,
  PRIMARY KEY (`CODE_ETAPE`),
  KEY `CODE_FORMATION` (`CODE_FORMATION`),
  KEY `DOSSIER_PDF` (`DOSSIER_PDF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `voeu`
--

INSERT INTO `voeu` (`CODE_ETAPE`, `CODE_FORMATION`, `ETAPE`, `DOSSIER_PDF`) VALUES
('BGE303', '3BGE', 'L3 Parcours Méthodes Informatiques Appliquées à la Gestion des Entreprises (MIAGE)', NULL),
('BIG400', '5BIG', 'M1 MIAGE', NULL),
('BIG500', '5BIG', 'M2 MIAGE', NULL),
('BIN303', '3SIN', 'L3 Parcours Méthodes Informatiques Appliquées à la Gestion des Entreprises (MIAGE)', NULL),
('SIN3', 'SIN3', 'Licence 2 informatique', NULL);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `choix`
--
ALTER TABLE `choix`
  ADD CONSTRAINT `choix_ibfk_1` FOREIGN KEY (`INFORMATION`) REFERENCES `information` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `cursus`
--
ALTER TABLE `cursus`
  ADD CONSTRAINT `cursus_ibfk_3` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `dossier` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cursus_ibfk_4` FOREIGN KEY (`ID_ETUDIANT`) REFERENCES `dossier` (`ID_ETUDIANT`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `dependre`
--
ALTER TABLE `dependre`
  ADD CONSTRAINT `dependre_ibfk_2` FOREIGN KEY (`CODE_ETAPE`) REFERENCES `voeu` (`CODE_ETAPE`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dependre_ibfk_1` FOREIGN KEY (`ID_DOSSIER`) REFERENCES `dossier_pdf` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `document_specifique`
--
ALTER TABLE `document_specifique`
  ADD CONSTRAINT `document_specifique_ibfk_1` FOREIGN KEY (`DOSSIER_PDF`) REFERENCES `dossier_pdf` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD CONSTRAINT `dossier_ibfk_5` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `formation` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dossier_ibfk_6` FOREIGN KEY (`TITULAIRE`) REFERENCES `titulaire` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `dossier_pdf`
--
ALTER TABLE `dossier_pdf`
  ADD CONSTRAINT `dossier_pdf_ibfk_1` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `formation` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `experience_ibfk_3` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `dossier` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `experience_ibfk_4` FOREIGN KEY (`ID_ETUDIANT`) REFERENCES `dossier` (`ID_ETUDIANT`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `faire`
--
ALTER TABLE `faire`
  ADD CONSTRAINT `faire_ibfk_3` FOREIGN KEY (`CODE_ETAPE`) REFERENCES `voeu` (`CODE_ETAPE`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `faire_ibfk_5` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `dossier` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `faire_ibfk_6` FOREIGN KEY (`ID_ETUDIANT`) REFERENCES `dossier` (`ID_ETUDIANT`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `formation`
--
ALTER TABLE `formation`
  ADD CONSTRAINT `formation_ibfk_1` FOREIGN KEY (`FACULTE`) REFERENCES `faculte` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `information`
--
ALTER TABLE `information`
  ADD CONSTRAINT `information_ibfk_3` FOREIGN KEY (`DOSSIER_PDF`) REFERENCES `dossier_pdf` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `information_ibfk_2` FOREIGN KEY (`TYPE`) REFERENCES `type` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `se_derouler`
--
ALTER TABLE `se_derouler`
  ADD CONSTRAINT `se_derouler_ibfk_4` FOREIGN KEY (`CODE_ETAPE`) REFERENCES `voeu` (`CODE_ETAPE`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `se_derouler_ibfk_5` FOREIGN KEY (`ID`) REFERENCES `ville` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `voeu`
--
ALTER TABLE `voeu`
  ADD CONSTRAINT `voeu_ibfk_2` FOREIGN KEY (`CODE_FORMATION`) REFERENCES `formation` (`CODE_FORMATION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `voeu_ibfk_3` FOREIGN KEY (`DOSSIER_PDF`) REFERENCES `dossier_pdf` (`ID`) ON DELETE SET NULL ON UPDATE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
